# Free Fire Tournament Telegram Bot + Web Admin Panel

## Run
1. Install Python 3.10+.
2. `pip install -r requirements.txt`
3. Set `ADMIN_PASSWORD` and `SECRET_KEY`.
4. For the Telegram bot, set `BOT_TOKEN` from BotFather.
5. Start website: `python app.py`
6. In another terminal start bot: `python bot.py`

Default admin password is `admin123` only for local testing. Change it before deployment.

This starter is for legitimate tournament registration/management. It does not include cheats, account access, or anti-cheat bypass functionality.
