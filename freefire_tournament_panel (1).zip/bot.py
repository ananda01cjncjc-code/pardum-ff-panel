import os, sqlite3, asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

TOKEN=os.environ.get("BOT_TOKEN","")
DB="tournament.db"

def tournaments():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row
    rows=c.execute("SELECT * FROM tournaments WHERE status='Open' ORDER BY id DESC").fetchall()
    c.close(); return rows

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows=tournaments()
    if not rows:
        await update.message.reply_text("Abhi koi tournament open nahi hai.")
        return
    kb=[[InlineKeyboardButton(f"🏆 {r['name']} — {r['entry_fee']}",
                              callback_data=f"t:{r['id']}")] for r in rows]
    await update.message.reply_text(
        "🔥 Free Fire Tournament Bot\n\nTournament select karo:",
        reply_markup=InlineKeyboardMarkup(kb))

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("/start - Open tournaments\n/help - Help")

def main():
    if not TOKEN:
        raise RuntimeError("BOT_TOKEN environment variable set karo.")
    app=Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.run_polling()

if __name__=="__main__":
    main()
